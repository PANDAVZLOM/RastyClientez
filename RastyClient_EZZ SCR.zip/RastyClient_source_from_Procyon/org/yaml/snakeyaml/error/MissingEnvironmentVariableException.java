// 
// Decompiled by Procyon v0.5.36
// 

package org.yaml.snakeyaml.error;

public class MissingEnvironmentVariableException extends YAMLException
{
    public MissingEnvironmentVariableException(final String message) {
        super(message);
    }
}
