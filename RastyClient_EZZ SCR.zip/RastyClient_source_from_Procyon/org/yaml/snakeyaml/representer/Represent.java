// 
// Decompiled by Procyon v0.5.36
// 

package org.yaml.snakeyaml.representer;

import org.yaml.snakeyaml.nodes.Node;

public interface Represent
{
    Node representData(final Object p0);
}
