// 
// Decompiled by Procyon v0.5.36
// 

package org.yaml.snakeyaml.introspector;

public enum BeanAccess
{
    DEFAULT, 
    FIELD, 
    PROPERTY;
}
