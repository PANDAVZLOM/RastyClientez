// 
// Decompiled by Procyon v0.5.36
// 

package org.yaml.snakeyaml.comments;

public enum CommentType
{
    BLANK_LINE, 
    BLOCK, 
    IN_LINE;
}
