// 
// Decompiled by Procyon v0.5.36
// 

package us.myles.ViaVersion.api.protocol;

@Deprecated
public class ProtocolRegistry
{
    @Deprecated
    public static int SERVER_PROTOCOL;
    
    static {
        ProtocolRegistry.SERVER_PROTOCOL = -1;
    }
}
