// 
// Decompiled by Procyon v0.5.36
// 

package com.viaversion.viaversion.exception;

public interface CancelCodecException
{
}
