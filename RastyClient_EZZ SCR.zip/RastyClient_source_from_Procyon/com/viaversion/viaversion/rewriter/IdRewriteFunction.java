// 
// Decompiled by Procyon v0.5.36
// 

package com.viaversion.viaversion.rewriter;

@FunctionalInterface
public interface IdRewriteFunction
{
    int rewrite(final int p0);
}
