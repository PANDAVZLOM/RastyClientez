// 
// Decompiled by Procyon v0.5.36
// 

package com.github.lunatrius.schematica.client.world;

import com.github.lunatrius.schematica.api.ISchematic;
import com.github.lunatrius.core.util.math.MBlockPos;

public class SchematicWorld
{
    public final MBlockPos position;
    
    public SchematicWorld() {
        this.position = (MBlockPos)"cringe";
    }
    
    public ISchematic getSchematic() {
        throw new LinkageError("LOL");
    }
}
