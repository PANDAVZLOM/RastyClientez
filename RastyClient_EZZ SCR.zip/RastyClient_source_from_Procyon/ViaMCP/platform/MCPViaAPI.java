// 
// Decompiled by Procyon v0.5.36
// 

package ViaMCP.platform;

import io.netty.buffer.ByteBuf;
import java.util.UUID;
import com.viaversion.viaversion.ViaAPIBase;

public class MCPViaAPI extends ViaAPIBase<UUID>
{
}
