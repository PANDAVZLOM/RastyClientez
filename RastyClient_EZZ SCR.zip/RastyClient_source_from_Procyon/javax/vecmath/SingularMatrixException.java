// 
// Decompiled by Procyon v0.5.36
// 

package javax.vecmath;

public class SingularMatrixException extends RuntimeException
{
    public SingularMatrixException() {
    }
    
    public SingularMatrixException(final String str) {
        super(str);
    }
}
